// Package dansk greets the user in Danish.
package dansk

import "fmt"

// Hej prints the string "Hej!".
func Hej() {
	fmt.Println("Hej!")
}

// GodMorgen prints the string "God morgen!".
func GodMorgen() {
	fmt.Println("God morgen!")
}
